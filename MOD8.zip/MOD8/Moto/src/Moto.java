/**
 * @author Samuel.Fernandes
 */
public class Moto {
    public static void main(String[] args) throws Exception {
        System.out.println("Hello, World!");
            /*
            GS1200 gs1200 = new GS1200();
            Tiger tiger = new Tiger();
            Twin twin = new Twin();
            */
            
    }
}
