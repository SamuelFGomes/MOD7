public class GS1200 {
    private String Moto1;

    public String getMoto1() {
        return Moto1;
    }

    public void setMoto1(String moto1) {
        Moto1 = moto1;
    }
}
