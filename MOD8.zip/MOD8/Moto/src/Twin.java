public class Twin {
    private String Moto3;

    public String getMoto3() {
        return Moto3;
    }

    public void setMoto3(String moto3) {
        Moto3 = moto3;
    }
}
