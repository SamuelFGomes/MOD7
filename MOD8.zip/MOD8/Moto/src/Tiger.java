public class Tiger {
    private String Moto2;

    public String getMoto2() {
        return Moto2;
    }

    public void setMoto2(String moto2) {
        Moto2 = moto2;
    }
}
